﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EventsOrganizer.Models;

namespace EventsOrganizer
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        DBEntities db = new DBEntities();
        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var user = db.Users.FirstOrDefault(x => x.Email == email);

            if (user != null)
            {
                // В базе данных нет поля Password, поэтому используем Phone как пароль
                // (на основе структуры БД)
                if (user.Phone == password)
                {
                    MessageBox.Show($"Добро пожаловать, {user.Name} {user.LastName}!",
                        "Успешный вход", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Навигация в зависимости от роли
                    switch (user.RoleID)
                    {
                        case 1:
                            NavigationService.Navigate(new UserPage(user));
                            break;
                        case 2:
                            NavigationService.Navigate(new ManagerPage(user));
                            break;
                        case 3:
                            NavigationService.Navigate(new AdminPage(user));
                            break;
                        default:
                            NavigationService.Navigate(new UserPage(user));
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Неверный пароль!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Пользователь с таким email не найден!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RegistrationHyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            NavigationService.Navigate(new RegistrationPage());
        }
    }
}
    

