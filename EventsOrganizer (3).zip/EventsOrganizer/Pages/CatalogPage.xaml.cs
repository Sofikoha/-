﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EventsOrganizer.Models;

namespace EventsOrganizer
{
    /// <summary>
    /// Логика взаимодействия для CatalogPage.xaml
    /// </summary>
    public partial class CatalogPage : Page
    {
        DBEntities db = new DBEntities();

        public CatalogPage()
        {
            try
            {
                InitializeComponent();
                db = new DBEntities();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadData()
        {
            try
            {
                if (db == null)
                    db = new DBEntities();

                var events = db.Events.ToList();
                if (EventsListView != null)
                {
                    EventsListView.ItemsSource = events;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void searchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            SearchList();
        }

        private void statusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SearchList();
        }

        private void sortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SearchList();
        }

        private void SearchList()
        {
            try
            {
                if (EventsListView == null) return;
                if (db == null) db = new DBEntities();

                var ListResult = db.Events.ToList();
     
                if (searchBox != null && !string.IsNullOrWhiteSpace(searchBox.Text))
                {
                    ListResult = ListResult.Where(x => x.EventName.ToLower().Contains(searchBox.Text.ToLower())).ToList();
                }

                if (statusComboBox != null && statusComboBox.SelectedIndex >= 0 && statusComboBox.SelectedItem != null)
                {
                    var selectedItem = statusComboBox.SelectedItem as ComboBoxItem;
                    if (selectedItem != null)
                    {
                        var selectedStatus = selectedItem.Content.ToString();
                        var today = DateTime.Now.Date;

                        switch (selectedStatus)
                        {
                            case "Предстоящие":
                                ListResult = ListResult.Where(x => x.EventDate > today).ToList();
                                break;
                            case "Прошедшие":
                                ListResult = ListResult.Where(x => x.EventDate < today).ToList();
                                break;
                            case "Сегодня":
                                ListResult = ListResult.Where(x => x.EventDate == today).ToList();
                                break;
                        }
                    }
                }


                if (sortComboBox != null && sortComboBox.SelectedIndex >= 0 && sortComboBox.SelectedItem != null)
                {
                    var selectedItem = sortComboBox.SelectedItem as ComboBoxItem;
                    if (selectedItem != null)
                    {
                        var sortOption = selectedItem.Content.ToString();

                        switch (sortOption)
                        {
                            case "По названию":
                                ListResult = ListResult.OrderBy(x => x.EventName).ToList();
                                break;
                            case "По дате":
                                ListResult = ListResult.OrderBy(x => x.EventDate).ToList();
                                break;
                            case "По гостям":
                                ListResult = ListResult.OrderBy(x => x.GuestCount).ToList();
                                break;
                            case "По бюджету":
                                ListResult = ListResult.OrderBy(x => x.TotalBudget).ToList();
                                break;
                        }
                    }
                }

                EventsListView.ItemsSource = ListResult;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void addEvent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AddEditEventWindow addEditWindow = new AddEditEventWindow();
                addEditWindow.Owner = Window.GetWindow(this);

                if (addEditWindow.ShowDialog() == true)
                {
                    db = new DBEntities();
                    SearchList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void updateEvent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (EventsListView == null) return;

                var selectedItem = EventsListView.SelectedItem as Events;
                if (selectedItem != null)
                {
                    AddEditEventWindow addEditWindow = new AddEditEventWindow(selectedItem);
                    addEditWindow.Owner = Window.GetWindow(this);

                    if (addEditWindow.ShowDialog() == true)
                    {
                        db = new DBEntities();
                        SearchList();
                    }
                }
                else
                {
                    MessageBox.Show("Выберите мероприятие", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void deleteEvent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (EventsListView == null) return;

                var selectedItem = EventsListView.SelectedItem as Events;
                if (selectedItem != null)
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите удалить мероприятие?",
                        "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        db.Events.Remove(selectedItem);
                        db.SaveChanges();
                        db = new DBEntities();
                        SearchList();

                        MessageBox.Show("Мероприятие удалено", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Выберите мероприятие", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}