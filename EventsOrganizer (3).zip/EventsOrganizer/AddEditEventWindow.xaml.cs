﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EventsOrganizer.Models;
using Microsoft.Win32;

namespace EventsOrganizer
{
    /// <summary>
    /// Логика взаимодействия для AddEditEventWindow.xaml
    /// </summary>
    public partial class AddEditEventWindow : Window
    {
        DBEntities db = new DBEntities();
        Events Events;
        bool isEditMode = false;
        byte[] currentImage = null;

        public AddEditEventWindow()
        {
            InitializeComponent();
        }

        public AddEditEventWindow(Events existingEvent)
        {
            InitializeComponent();
            isEditMode = true;
            Events = existingEvent;

            eventNameBox.Text = Events.EventName;
            eventDatePicker.SelectedDate = Events.EventDate;

            if (Events.TimeStart.HasValue)
                timeStartBox.Text = Events.TimeStart.Value.ToString(@"hh\:mm");

            if (Events.TimeEnd.HasValue)
                timeEndBox.Text = Events.TimeEnd.Value.ToString(@"hh\:mm");

            guestCountBox.Text = Events.GuestCount.ToString();
            totalBudgetBox.Text = Events.TotalBudget.ToString();

            if (Events.Image != null && Events.Image.Length > 0)
            {
                eventImage.Source = ByteArrayToImage(Events.Image);
            }
        }

        private BitmapImage ByteArrayToImage(byte[] imageData)
        {
            if (imageData == null || imageData.Length == 0) return null;

            using (MemoryStream ms = new MemoryStream(imageData))
            {
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.StreamSource = ms;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.EndInit();
                image.Freeze();
                return image;
            }
        }

        private byte[] ImageToByteArray(BitmapImage image)
        {
            if (image == null) return null;

            using (MemoryStream ms = new MemoryStream())
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image));
                encoder.Save(ms);
                return ms.ToArray();
            }
        }

        private void loadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    BitmapImage image = new BitmapImage();
                    image.BeginInit();
                    image.UriSource = new Uri(openFileDialog.FileName);
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.EndInit();
                    image.Freeze();

                    eventImage.Source = image;
                    currentImage = ImageToByteArray(image);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки изображения: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(eventNameBox.Text))
            {
                MessageBox.Show("Введите название мероприятия!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (eventDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите дату проведения!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(timeStartBox.Text))
            {
                MessageBox.Show("Введите время начала!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(timeEndBox.Text))
            {
                MessageBox.Show("Введите время окончания!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            TimeSpan timeStart;
            if (!TimeSpan.TryParse(timeStartBox.Text, out timeStart))
            {
                MessageBox.Show("Неверный формат времени начала! Используйте HH:MM", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            TimeSpan timeEnd;
            if (!TimeSpan.TryParse(timeEndBox.Text, out timeEnd))
            {
                MessageBox.Show("Неверный формат времени окончания! Используйте HH:MM", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            int guestCount;
            if (!int.TryParse(guestCountBox.Text, out guestCount) || guestCount < 0)
            {
                MessageBox.Show("Введите корректное количество гостей!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            decimal totalBudget;
            if (!decimal.TryParse(totalBudgetBox.Text, out totalBudget) || totalBudget < 0)
            {
                MessageBox.Show("Введите корректный бюджет!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateFields())
                return;

            try
            {
                if (isEditMode)
                {
                    var eventToUpdate = db.Events.Find(Events.EventID);
                    if (eventToUpdate != null)
                    {
                        eventToUpdate.EventName = eventNameBox.Text;
                        eventToUpdate.EventDate = eventDatePicker.SelectedDate.Value;
                        eventToUpdate.TimeStart = TimeSpan.Parse(timeStartBox.Text);
                        eventToUpdate.TimeEnd = TimeSpan.Parse(timeEndBox.Text);
                        eventToUpdate.GuestCount = int.Parse(guestCountBox.Text);
                        eventToUpdate.TotalBudget = decimal.Parse(totalBudgetBox.Text);

                        if (currentImage != null)
                            eventToUpdate.Image = currentImage;

                        db.SaveChanges();
                        MessageBox.Show("Мероприятие успешно обновлено!", "Успех",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    Events newEvent = new Events()
                    {
                        EventName = eventNameBox.Text,
                        EventDate = eventDatePicker.SelectedDate.Value,
                        TimeStart = TimeSpan.Parse(timeStartBox.Text),
                        TimeEnd = TimeSpan.Parse(timeEndBox.Text),
                        GuestCount = int.Parse(guestCountBox.Text),
                        TotalBudget = decimal.Parse(totalBudgetBox.Text),
                        Image = currentImage
                    };

                    db.Events.Add(newEvent);
                    db.SaveChanges();
                    MessageBox.Show("Мероприятие успешно добавлено!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }

                this.DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            Close();
        }
    }
}